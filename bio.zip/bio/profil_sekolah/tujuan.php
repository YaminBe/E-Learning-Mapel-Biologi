<h2>Tujuan</h2>
a)	Mewujudkan siswa yang berprestasi dibidang Akademik maupun dibidang non akademik.
b)	Mewujudkan perilaku sesuai dengan ajaran agama yang dianut sesuai dengan perkembangan remaja.
c)	Mewujudkan pengembangan diri secara optimal dengan memanfaatkan kelebihan diri serta memperbaiki kekurangannya
d)	Mewujudkan penunjukan sikap percaya diri dan bertanggung jawab atas perilaku,perbuatan dan perkerjaanya.
