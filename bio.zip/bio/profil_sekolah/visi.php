<h2>Visi</h2>
Terwujudnya lulusan yang “Berprestasi, Terampilan,Taat beribadah, dan Berakhlak mulia, berbudaya dan menguasai IPTEK
a)	Terwujudnya siswa yang berprestasi di bidang Akademik maupun dibidang non akademik
b)	Terwujudnya prilaku sesuai dengan ajaran agama yang dianut sesuai dengan perkembangan remaja
c)	Terwujudnya pengembangan diri secara optimal dengan memanfaatkan kelebihan diri serta memperbaiki kekurangan
d)	Terwujudnya penunjukan sikap percaya diri dan bertanggung jawab atas perilaku,perbuatan dan pekerjaannya.
<br>

<h2>MISI SMA Muhammadiyah</h2>
a)	Mewujudkan siswa yang berprestasi dibidang Akademik maupun dibidang non akademik.
b)	Mewujudkan perilaku sesuai dengan ajaran agama yang dianut sesuai dengan perkembangan remaja.
c)	Mewujudkan pengembangan diri secara optimal dengan memanfaatkan kelebihan diri serta memperbaiki kekurangannya
d)	Mewujudkan penunjukan sikap percaya diri dan bertanggung jawab atas perilaku,perbuatan dan perkerjaanya.
