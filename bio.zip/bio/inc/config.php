<?php
			
							//fungsi untuk mengkonversi size file
					function formatBytes($bytes, $precision = 2) { 
					$units = array('B', 'KB', 'MB', 'GB', 'TB'); 
				
					$bytes = max($bytes, 0); 
					$pow = floor(($bytes ? log($bytes) : 0) / log(1024)); 
					$pow = min($pow, count($units) - 1); 
				
					$bytes /= pow(1024, $pow); 
				
					return round($bytes, $precision) . ' ' . $units[$pow]; 
				} 
			
			if(@$_POST['proses']){
				$allowed_ext	= array('doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'pdf', 'rar', 'zip');
				
				$file_name		= $_FILES['file']['name'];
				$file_ext		= strtolower(end(explode('.', $file_name)));
				$file_size		= $_FILES['file']['size'];
				$file_tmp		= $_FILES['file']['tmp_name'];
				
				
				$nama			= $_POST['nama'];
				$tgl			= date("Y-m-d");
				$nm_guru		= $_POST['nm_guru'];

				if(in_array($file_ext, $allowed_ext) === true){
					if($file_size < 1044070){
						$lokasi = 'files/'.$nama.'.'.$file_ext;
						move_uploaded_file($file_tmp, $lokasi);
						$in = mysql_query("INSERT INTO tb_tugas VALUES(NULL, '$tgl', '$nm_guru','$nama', '$file_ext', '$file_size', '$lokasi')");
						if($in){
							echo '<div class="panel panel-primary">SUCCESS: File berhasil di Upload!</div>';
						}else{
							echo '<div class="error">ERROR: Gagal upload file!</div>';
						}
					}else{
						echo '<div class="error">ERROR: Besar ukuran file (file size) maksimal 1 Mb!</div>';
					}
				}else{
					echo '<div class="error">ERROR: Ekstensi file tidak di izinkan!</div>';
				}
			}
			
			?> 
