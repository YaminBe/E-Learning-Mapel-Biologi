
<?php
session_start();
unset($_SESSION['guru']); 
echo "<script>window.location='../';</script>";


?>