
<?php
$username 	= "biow6888_revi";
$password 	= "@revi@";
$host		= "localhost";
$database	= "biow6888_revi";
mysql_connect($host,$username,$password);
mysql_select_db($database);
?>
