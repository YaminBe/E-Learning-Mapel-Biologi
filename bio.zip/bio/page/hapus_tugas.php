


<?php
$kdtugas = @$_GET['kdtugas'];
mysql_query("delete from tb_tugas where id_tugas = '$kdtugas'") or die(mysql_error());
?>
 <script type="text/javascript">
        alert("data berhasil di Hapus!!");  
        window.location.href="?page=tugas&action=input_tugas";
 </script>
