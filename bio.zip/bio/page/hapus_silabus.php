
<?php
$kdsilabus = @$_GET['kdsilabus'];
mysql_query("delete from tb_silabus where id_silabus = '$kdsilabus'") or die(mysql_error());
?>
 <script type="text/javascript">
        alert("data berhasil di Hapus!!");  
        window.location.href="?page=user&action=input_silabus";
 </script>
