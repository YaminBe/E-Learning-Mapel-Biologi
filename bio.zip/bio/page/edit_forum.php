<fieldset>
	<legend> Edit Forum Diskusi </legend>
	<?php
$kdforum = @$_GET['kdforum'];
$sql = mysql_query("select * from tb_forum where kode = '$kdforum'") or die(mysql_error());
$data = mysql_fetch_array($sql);

?>
	<form class="form-validate form-horizontal" id="feedback_form" method="post" action="" enctype="multipart/form-data">
<div class="form-group ">
<label for="cname" class="control-label col-lg-2">Kode Diskusi<span class="required">*</span></label>
<div class="col-lg-7">
<input type="text" name="kode" class="form-control" value="<?php echo $data['kode']; ?>"required />
</div>
</div>
<div class="form-group ">
<label for="cname" class="control-label col-lg-2">Nama<span class="required">*</span></label>
<div class="col-lg-7">
<input type="text" name="nama" class="form-control" value="<?php echo $data['nama']; ?>" required />
</div>
</div>

<div class="form-group ">
<label for="cname" class="control-label col-lg-2">judul<span class="required">*</span></label>
<div class="col-lg-7">
<input type="text" name="judul" class="form-control" value="<?php echo $data['judul']; ?>" required />
</div>
</div>

<div class="form-group ">
<label for="cname" class="control-label col-lg-2"> Pembahasn<span class="required">*</span></label>
<div class="col-lg-7">
	<textarea name="pembahasan" class="form-control" value="<?php echo $data['pembahasan']; ?>"></textarea>
	
</div>
</div>
<div class="form-group ">
<label for="cname" class="control-label col-lg-2"> Keterangan<span class="required">*</span></label>
<div class="col-lg-7">
	<textarea name="ket" class="form-control" value="<?php echo $data['ket']; ?>"></textarea>
	
</div>
</div>



<div class="form-group">
<div class="col-lg-offset-2 col-lg-10">
<input type="submit" name="edit" value="Edit Data" class="btn btn-success">
<button class="btn btn-danger" type="button">Cancel</button>
</div>
</div>
</form>

<?php
include 'inc/koneksi.php';
if (@$_POST['edit']) {
	@$nama = mysql_real_escape_string($_POST['nama']);
	@$judul = mysql_real_escape_string($_POST['judul']);
	@$pembahasan = mysql_real_escape_string($_POST['pembahasan']);
	@$ket = mysql_real_escape_string($_POST['ket']);	
	
	mysql_query("update tb_forum set nama ='$nama',judul='$judul',pembahasan='$pembahasan',ket='$ket' where kode='$kdforum' ") or die(mysql_error());
        ?>
         <script type="text/javascript">
          alert("data berhasil di EDIT !!");  
           window.location.href="?page=tugas&action=forum";
         </script>

         <?php  
}



?>
</fieldset>