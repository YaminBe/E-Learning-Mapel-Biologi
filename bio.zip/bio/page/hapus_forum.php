<?php
$kdforum = @$_GET['kdforum'];
mysql_query("delete from tb_forum where kode = '$kdforum'") or die(mysql_error());
?>
 <script type="text/javascript">
        alert("data berhasil di Hapus!!");  
        window.location.href="?page=tugas&action=forum";
 </script>