<script src="assets/dist/sweetalert.min.js"></script>
  <link rel="stylesheet" href="assets/dist/sweetalert.css">

<?php
$kduser = @$_GET['kduser'];
mysql_query("delete from tb_user where kode_user = '$kduser'") or die(mysql_error());
?>
 <script type="text/javascript">
        swal(" Sukses !", "Data berhasil di hapus!", "success")
        window.location.href="?page=user&action=tampil_data";
 </script>


