<div class="row">
<div class="col-lg-12">
<section class="panel">
<header class="panel-heading">
Form validations
</header>
<div class="panel-body">
<div class="form">

<div class="panel-body">
<div class="table-responsive table-bordered">
<table class="table">
<thead class="panel-body">
<tr>                                                                                
<th>No</th>
<th>Kode User</th>
<th>Username</th>
<th>Password</th>
<th>Nama Lengkap</th>
<th>Level</th>
<th>Gambar</th>
<th><center>Opsi</center></th>

</tr>                                         
</thead>
<?php
$sql = mysql_query("select * from tb_login") or die (mysql_error());


$no=1;


while ($data = mysql_fetch_array($sql)){                                                         

?>
<tbody>
<tr>
<td><?php echo $no; ?></td>
           
<td><?php echo $data['kode_user']; ?></td>

<td><?php echo $data ['username']; ?></td>

<td><?php echo $data ['password']; ?></td>

<td><?php echo $data ['nama_lengkap']; ?></td>

<td><?php echo $data ['level']; ?></td>
<td><img src="img/<?php echo $data ['gambar']; ?>" width="50px" class="img-circle"/></td>
<td>

<a href="?page=user&action=edit&kduser=<?php echo $data['kode_user']; ?>"><button class="btn btn-primary"><i class="fa fa-edit "></i> Edit</button></a>

<button class="btn btn-danger"><i class="fa fa-pencil"></i> Hapus</button></td>




</tr>
<?php
$no++;
};
?>



</tbody>
</table>

</div>
</div>

</div>

</div>
</section>
</div>
</div>