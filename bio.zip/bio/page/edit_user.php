
<!-- Form validations 

<div class="row">
<div class="col-lg-12">
<section class="panel">
<header class="panel-heading">
Edit Data User
</header>

<div class="panel-body">
<div class="form">
<?php
$kduser = @$_GET['kduser'];
$sql = mysql_query("select * from tb_user where kode_user = '$kduser'") or die(mysql_error());
$data = mysql_fetch_array($sql);

?>

<form class="form-validate form-horizontal" id="feedback_form" method="post" action="" enctype="multipart/form-data">
<div class="form-group ">
<label for="cname" class="control-label col-lg-2">Kode User<span class="required">*</span></label>
<div class="col-lg-7">
<input type="text" name="kode_user" class="form-control" value="<?php echo $data['kode_user']; ?>"required />
</div>
</div>
<div class="form-group ">
<label for="cname" class="control-label col-lg-2">Username<span class="required">*</span></label>
<div class="col-lg-7">
<input type="text" name="username" value="<?php echo $data['username']; ?>" class="form-control"required />
</div>
</div>
<div class="form-group ">
<label for="cname" class="control-label col-lg-2">Password<span class="required">*</span></label>
<div class="col-lg-7">
<input type="text" name="password" value="<?php echo $data['password']; ?>" class="form-control"required />
</div>
</div>
<div class="form-group ">
<label for="cname" class="control-label col-lg-2">Ulangi Password<span class="required">*</span></label>
<div class="col-lg-7">
<input type="text" name="pass" class="form-control"required />
</div>
</div>

<div class="form-group ">
<label for="cname" class="control-label col-lg-2">Nama Lengkap<span class="required">*</span></label>
<div class="col-lg-7">
<input class="form-control" id="cname" name="nama_lengkap" type="text" required />
</div>
</div>
<div class="form-group">
<label class="control-label col-lg-2" for="inputSuccess">Jenis Kelamin</label>
<div class="col-lg-4">
<select name="jenis_kelamin" class="form-control m-bot15">
<option>-- Pilih Jenis Kelamin --</option>
<option>Laki-laki</option>
<option>Perempuan</option>

</select>
</div>
</div>

<div class="form-group ">
<label for="cname" class="control-label col-lg-2">Alamat<span class="required">*</span></label>
<div class="col-lg-5">
<textarea class="form-control" name="alamat"></textarea>
</div>
</div>
<div class="form-group">
<label class="control-label col-lg-2" for="inputSuccess">Level</label>
<div class="col-lg-4">
<select name="level" class="form-control m-bot15">
<option>-- Pilih Level --</option>
<option>admin</option>
<option>guru</option>
<option>siswa</option>
</select>
</div>
</div>
<div class="form-group">
<label class="col-sm-2 col-sm-2 control-label">Foto</label>
<div class="col-sm-8">
<input type="file" name="gambar" class="btn btn-round btn-info">

</div>
</div>



<div class="form-group">
<div class="col-lg-offset-2 col-lg-10">
<input type="submit" name="simpan" value="Simpan" class="btn btn-primary">
<button class="btn btn-danger" type="button">Cancel</button>
</div>
</div>
</form>


</div>

</div>
</section>
</div>
</div>
-->

<fieldset>
	<legend> Edit Data User </legend>
	<?php
$kduser = @$_GET['kduser'];
$sql = mysql_query("select * from tb_user where kode_user = '$kduser'") or die(mysql_error());
$data = mysql_fetch_array($sql);

?>
	<form class="form-validate form-horizontal" id="feedback_form" method="post" action="" enctype="multipart/form-data">
<div class="form-group ">
<label for="cname" class="control-label col-lg-2">Kode User<span class="required">*</span></label>
<div class="col-lg-7">
<input type="text" name="kode_user" class="form-control" value="<?php echo $data['kode_user']; ?>"required />
</div>
</div>
<div class="form-group ">
<label for="cname" class="control-label col-lg-2">Username<span class="required">*</span></label>
<div class="col-lg-7">
<input type="text" name="username" class="form-control" value="<?php echo $data['username']; ?>" required />
</div>
</div>

<div class="form-group ">
<label for="cname" class="control-label col-lg-2">Password<span class="required">*</span></label>
<div class="col-lg-7">
<input type="text" name="pass" class="form-control" value="<?php echo $data['pass']; ?>" required />
</div>
</div>

<div class="form-group ">
<label for="cname" class="control-label col-lg-2">Nama Lengkap<span class="required">*</span></label>
<div class="col-lg-7">
<input class="form-control" id="cname" name="nama_lengkap" type="text" value="<?php echo $data['nama_lengkap']; ?>" required />
</div>
</div>
<!--
<div class="form-group">	 
<label class="control-label col-lg-2" for="inputSuccess">Jenis Kelamin</label>
<div class="col-lg-4">
	<input type="radio" name="jenis_kelamin" value="Laki-laki" required <?php if($data['jenis_kelamin'] =='Laki-laki'){echo "checked";} ?> > Laki-laki
	<br>
	<input type="radio" name="jenis_kelamin" value="Perempuan" required <?php if($data['jenis_kelamin'] =='Perempuan'){echo "checked"; } ?>> Perempuan
</div>
</div>
-->
<div class="form-group ">
<label for="cname" class="control-label col-lg-2">jk<span class="required">*</span></label>
<div class="col-lg-5">
<input type="text" name="jenis_kelamin" class="form-control" value="<?php echo $data['jenis_kelamin']; ?>" required />
</div>
</div>

<div class="form-group ">
<label for="cname" class="control-label col-lg-2">Alamat<span class="required">*</span></label>
<div class="col-lg-5">
<input type="text" name="alamat" class="form-control" value="<?php echo $data['alamat']; ?>" required />
</div>
</div>




<div class="form-group">
<div class="col-lg-offset-2 col-lg-10">
<input type="submit" name="edit" value="Edit Data" class="btn btn-success">
<button class="btn btn-danger" type="button">Cancel</button>
</div>
</div>
</form>

<?php
include 'inc/koneksi.php';
if (@$_POST['edit']) {
	@$username = mysql_real_escape_string($_POST['username']);
	@$pass = mysql_real_escape_string($_POST['pass']);
	@$nama_lengkap = mysql_real_escape_string($_POST['nama_lengkap']);
	@$jenis_kelamin = mysql_real_escape_string($_POST['jenis_kelamin']);
	@$alamat = mysql_real_escape_string($_POST['alamat']);
	
	mysql_query("update tb_user set username ='$username',pass='$pass',password =md5('$pass'), nama_lengkap='$nama_lengkap',jenis_kelamin='$jenis_kelamin',alamat='$alamat' where kode_user='$kduser' ") or die(mysql_error());
        ?>
         <script type="text/javascript">
          alert("data berhasil di EDIT !!");  
           window.location.href="?page=user&action=tampil_data";
         </script>

         <?php  
}



?>
<!--


<?php
      
      $username = @$_POST['username'];      
      $pass = @$_POST['pass'];
      $nama_lengkap = @$_POST['nama_lengkap'];
      $jenis_kelamin = @$_POST['jenis_kelamin'];
      $alamat =@$_POST['alamat'];

      $sumber = @$_FILES['gambar']['tmp_name'];
      $target = 'gambar/';
      $nama_gambar = @$_FILES['gambar']['name'];


      $edit_data = @$_POST['edit_edit']; 

      if ($edit_data) {

        if ($username == "" || $pass == "" || $nama_lengkap == ""|| $jenis_kelamin=="" || $alamat ==""){
                  
           
       } else{
       	if($nama_gambar == ""){
       		mysql_query("UPDATE tb_user SET username ='$username',pass='$pass',password=md5('$pass'), nama_lengkap='$nama_lengkap',jenis_kelamin ='$jenis_kelamin',alamat ='$alamat' where kode_user='kduser' ") or die(mysql_error());
       		?>
         <script type="text/javascript">
          alert("data berhasil di EDIT !!");            
         </script>

         <?php  

        $pindah = move_uploaded_file($sumber, $target.$nama_gambar);

        if ($pindah) {
          mysql_query("UPDATE tb_user SET username ='$username',pass='$pass',password=md5('$pass'), nama_lengkap='$nama_lengkap',jenis_kelamin ='$jenis_kelamin',alamat ='$alamat',nama_gambar='$nama_gambar' where kode_user='kduser'") or die (mysql_error());
           	?>
         <script type="text/javascript">
          alert("data berhasil di EDIT !!");            
         </script>

         <?php  
          
       } else{


        ?> <script type="text/javascript"> alert("Upload gambar gaal")</script><?php
       }
}
        }

        }
      

?>
-->







</fieldset>


