<!-- TAMPIL TUGAS UNTUK GURU-->

<div class="row">
<div class="col-lg-12">
<section class="panel panel-warning">
<header class="panel-heading">
<center> <h3>Daftar Tugas Biologi</center>
</header>

<div class="panel-body">
<div class="table-responsive table-bordered">
<table class="table">
<thead class="panel-body">
<tr>                                                                                
<th>No</th>
<th>Tanggal Upload</th>
<th>Nama Siswa</th>
<th>Nama Tugas</th>
<th>Tipe File</th>
<th>Ukuran File</th>
<th>Keterangan</th>
<th><center>Download</center></th>


</tr>
                                      
</thead>

<?php
include('inc/koneksi.php');
//fungsi untuk mengkonversi size file
					function formatBytes($bytes, $precision = 2) { 
					$units = array('B', 'KB', 'MB', 'GB', 'TB'); 
				
					$bytes = max($bytes, 0); 
					$pow = floor(($bytes ? log($bytes) : 0) / log(1024)); 
					$pow = min($pow, count($units) - 1); 
				
					$bytes /= pow(1024, $pow); 
				
					return round($bytes, $precision) . ' ' . $units[$pow]; 
				} 

$sql = mysql_query("SELECT * FROM tb_tugas_siswa ORDER BY id_tgs_siswa DESC");
if(mysql_num_rows($sql) > 0){
$no = 1;
while($data = mysql_fetch_assoc($sql)){
echo '
<tbody>
<tr>
<td align="center">'.$no.'</td>
<td>'.$data['tanggal_upload'].'</td>
<td>'.$data['nm_siswa'].'</td>
<td>'.$data['nama_file'].'</td>
<td>'.$data['tipe_file'].'</td>
<td>'.formatBytes($data['ukuran_file']).'</td>
<td>'.$data['keterangan'].'</td>
<td><a href=" '.$data['file'].'"><img src="icon/download.jpg" width="95" height="38" /></a></td>




</tr>
';
$no++;
}
}else{
echo '
<tr bgcolor="#fff">
<td align="center" colspan="4" align="center">Tidak ada data!</td>
</tr>
';
}
?>



</tbody>
</table>



</div>

</div>
</section>
</div>
</div>
