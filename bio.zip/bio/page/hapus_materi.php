


<?php
$kdmateri = @$_GET['kdmateri'];
mysql_query("delete from tb_materi where id_materi = '$kdmateri'") or die(mysql_error());
?>
 <script type="text/javascript">
        alert("data berhasil di Hapus!!");  
        window.location.href="?page=user&action=input_materi";
 </script>
