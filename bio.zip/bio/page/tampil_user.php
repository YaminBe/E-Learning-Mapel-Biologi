<!--- tampil dataa user -->
 <script src="assets/dist/sweetalert.min.js"></script>
  <link rel="stylesheet" href="assets/dist/sweetalert.css">

<div class="row">
<div class="col-lg-11">
<section class="panel panel-danger">
<header class="panel-heading">

<center><img src="icon/user.png"></center>
</header>


<div class="panel-body">
<div class="table-responsive table-bordered">
<table class="table">
<thead class="panel-body">
<tr>                                                                                
<th>No</th>
<th>Kode User</th>
<th>Username</th>
<th>Password</th>
<th>Nama Lengkap</th>
<th>Jenis Kelamin</th>
<th>Alamat</th>
<th>Level</th>
<th>Foto</th>
<th><center>Opsi</center></th>
<th></th>
</tr>                                      
</thead>
<tbody>
	<?php
  $no = 1;

  $batas = 3;
  $hal = @$_GET['hal'];
  if (empty($hal)){
    $posisi = 0;
    $hal =1;

    }else{
      $posisi =($hal - 1) * $batas;
    }

	$sql_user = mysql_query("select * from tb_user limit $posisi,$batas" ) or die(mysql_error());
  $no =$posisi + 1;
  $cek =mysql_num_rows($sql_user);
  if($cek < 1){
    echo '<tr>  <td> Data Tidak ditemukan !!</td></tr>';

  }else{


	

	while ($data = mysql_fetch_array($sql_user)) { ?>
<tr>
  <td><?php echo $no++."." ;?></td>
  <td><?php echo $data['kode_user'];?></td>
  <td><?php echo $data['username'];?></td>
  <td><?php echo $data['pass'];?></td>
  <td><?php echo $data['nama_lengkap'];?></td>
  <td><?php echo $data['jenis_kelamin'];?></td>
  <td><?php echo $data['alamat'];?></td>
  <td><?php echo $data['level'];?></td>
  <td><img alt="" class="user-img-div" src="gambar/<?php echo $data['gambar'];?>" width="70px" ></td>
  <td>
    <a href="?page=user&action=edit&kduser=<?php echo $data['kode_user']; ?>"><button class="btn btn-primary">Edit</button></a>
    <a onclick="return confirm('Apakah kamu yakin ingin Hapus data ini ?')" href="?page=user&action=hapus&kduser=<?php echo $data['kode_user']; ?>"><button class="btn btn-danger">Hapus</button></a>
  	
  </td>
</tr>
<?php
 }

} ?>



</tbody>
</table>
 <div class="container">
<hr>
<div class="row">
<div class="col-lg-6">
  
<?php
$jml =mysql_num_rows(mysql_query("SELECT * FROM tb_user"));
echo "<img src='icon/dt.png'> <button class='btn btn-danger'><h2>".$jml."</button>";

?>
</div>
<div class="col-lg-6">

    <div>
        <ul class="pagination">
            <li><a href="#">«</a></li>
            
            <?php
            $jml_hal = ceil($jml / $batas);
            for ($i=1; $i<=$jml_hal; $i++){
            echo "<li><a href='?page=user&action=tampil_data&hal= $i'>$i</a></li> ";
            if($i != $hal){

            }else{
            echo "<li></li>";

            }
            }
            ?>
            
<li><a href="#">»</a></li>
</ul>                            



 
<!--
 <?php
$jml_hal = ceil($jml / $batas);
for ($i=1; $i<=$jml_hal; $i++){
echo "<a href='?page=user&action=tampil_data&hal= $i'><button class='btn btn-danger'>$i</button> </a> ";
if($i != $hal){

}else{
echo "<button class='btn btn-danger'>$i</button>";

}
}
?>
-->
</div>
</div>
<br>
</div>
<HR>
 

<a class="btn btn-primary" data-toggle="modal" href="#myModal"><i class="icon_plus_alt2"></i>
Tambahkan User
</a>
<!-- Modal -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
<div class="modal-dialog">
    <div class="modal-content">
        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
           
        </div>
        <div class="modal-body">
          <section class="panel">
<header class="panel-heading">
Tambah Data User
</header>
<div class="panel-body">
<div class="form">

<?php 
                      $carikode = mysql_query("select max(kode_user) from tb_user") or die(mysql_error());
                      $datakode = mysql_fetch_array($carikode);
                      if ($datakode) {
                        $nilaikode = substr($datakode[0], 1);
                        $kode = (int) $nilaikode;
                        $kode = $kode + 1;
                        $hasilkode= "U" .str_pad($kode, 3, "0", STR_PAD_LEFT);

 
                      } else{

                        $hasilkode = "U001";


                      }


                      ?>
<form class="form-validate form-horizontal" id="feedback_form" method="post" action="" enctype="multipart/form-data">
<div class="form-group ">
<label for="cname" class="control-label col-lg-2">Kode User<span class="required">*</span></label>
<div class="col-lg-7">
<input type="text" name="kode_user" class="form-control" value="<?php echo "$hasilkode";?>"required />
</div>
</div>
<div class="form-group ">
<label for="cname" class="control-label col-lg-2">Username<span class="required">*</span></label>
<div class="col-lg-7">
<input type="text" name="username" class="form-control"required />
</div>
</div>
<div class="form-group ">
<label for="cname" class="control-label col-lg-2">Password<span class="required">*</span></label>
<div class="col-lg-7">
<input type="text" name="password" class="form-control"required />
</div>
</div>
<div class="form-group ">
<label for="cname" class="control-label col-lg-2">Ulangi Password<span class="required">*</span></label>
<div class="col-lg-7">
<input type="text" name="pass" class="form-control"required />
</div>
</div>

<div class="form-group ">
<label for="cname" class="control-label col-lg-2">Nama Lengkap<span class="required">*</span></label>
<div class="col-lg-7">
<input class="form-control" id="cname" name="nama_lengkap" type="text" required />
</div>
</div>
<div class="form-group">
<label class="control-label col-lg-2" for="inputSuccess">Jenis Kelamin</label>
<div class="col-lg-4">
<select name="jenis_kelamin" class="form-control m-bot15">
<option>-- Pilih Jenis Kelamin --</option>
<option>Laki-laki</option>
<option>Perempuan</option>

</select>
</div>
</div>

<div class="form-group ">
<label for="cname" class="control-label col-lg-2">Alamat<span class="required">*</span></label>
<div class="col-lg-5">
<textarea class="form-control" name="alamat"></textarea>
</div>
</div>
<div class="form-group">
<label class="control-label col-lg-2" for="inputSuccess">Level</label>
<div class="col-lg-4">
<select name="level" class="form-control m-bot15">
<option>-- Pilih Level --</option>
<option>admin</option>
<option>guru</option>
<option>siswa</option>
</select>
</div>
</div>
<div class="form-group">
<label class="col-sm-2 col-sm-2 control-label">Foto</label>
<div class="col-sm-8">
<input type="file" name="gambar" class="btn btn-round btn-info">

</div>
</div>



<div class="form-group">
<div class="col-lg-offset-2 col-lg-10">
<input type="submit" name="simpan" value="Simpan" class="btn btn-primary">
<button class="btn btn-danger" type="button">Cancel</button>
</div>
</div>
</form>
<?php
      $kode_user = @$_POST['kode_user'];
      $username = @$_POST['username'];
      $password=md5(@$_POST['password']);
      $pass = @$_POST['pass'];
      $nama_lengkap = @$_POST['nama_lengkap'];
      $jenis_kelamin = @$_POST['jenis_kelamin'];
      $alamat =@$_POST['alamat'];
      $level = @$_POST['level'];


      $sumber = @$_FILES['gambar']['tmp_name'];
      $target = 'gambar/';
      $nama_gambar = @$_FILES['gambar']['name'];


      $simpan_data = @$_POST['simpan']; 

      if ($simpan_data) {

        if ($kode_user == "" || $username == "" || $password == "" || $pass == "" || $nama_lengkap == ""|| $jenis_kelamin=="" || $alamat =="" || $level== "" || $nama_gambar == ""){

        ?>
         <script type="text/javascript">
         alert("inputan ini ga boleh kosong");</script>
         <?php                    
           
       } else{


        $pindah = move_uploaded_file($sumber, $target.$nama_gambar);

        if ($pindah) {
          mysql_query("insert into tb_user values ('$kode_user','$username','$password','$pass','$nama_lengkap','$jenis_kelamin','$alamat','$level','$nama_gambar')") or die (mysql_error());
           ?>
      
    
         <script type="text/javascript"> 
               swal(" Sukses !", "You clicked the button!", "success") 
          window.location.href="?page=user&action=tampil_data";

      
         </script>

         <?php 
       } else{


        ?> <script type="text/javascript"> alert("Upload gambar gaal")</script><?php
       }

        }

        }
      

     ?>




</div>

</div>
</section>




        </div>
        <div class="modal-footer">
            <button data-dismiss="modal" class="btn btn-default" type="button">Keluar</button>
           
        </div>
    </div>
</div>
</div>
<!-- modal -->



</div>
<br>
</div>
</section>

</div>
</div>