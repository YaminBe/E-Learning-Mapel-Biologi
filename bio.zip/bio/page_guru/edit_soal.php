<fieldset>
	<legend> Edit Data User </legend>
	<?php
$kdsoal = @$_GET['kdsoal'];
$sql = mysql_query("select * from tbl_soal where id_soal = '$kdsoal'") or die(mysql_error());
$data = mysql_fetch_array($sql);

?>
	<form class="form-validate form-horizontal" id="feedback_form" method="post" action="" enctype="multipart/form-data">
<div class="form-group ">
<label for="cname" class="control-label col-lg-3">Nomor Soal<span class="required">*</span></label>
<div class="col-lg-7">
<input type="text" name="id_soal" value="<?php echo $data['id_soal']; ?>" class="form-control"/>
</div>
</div>
<div class="form-group ">
<label for="cname" class="control-label col-lg-3">Masukkan Soal<span class="required">*</span></label>
<div class="col-lg-7">
  <textarea name="soal" value="<?php echo $data['soal']; ?>" class="form-control"></textarea>

</div>
</div>


<div class="form-group ">
<label for="cname" class="control-label col-lg-3">Pilihan A<span class="required">*</span></label>
<div class="col-lg-7">
<input type="text" name="a" value="<?php echo $data['a']; ?>" class="form-control"required />
</div>
</div>
<div class="form-group ">
<label for="cname" class="control-label col-lg-3">Pilihan B<span class="required">*</span></label>
<div class="col-lg-7">
<input type="text" name="b" value="<?php echo $data['b']; ?>" class="form-control"required />
</div>
</div>
<div class="form-group ">
<label for="cname" class="control-label col-lg-3">Pilihan C<span class="required">*</span></label>
<div class="col-lg-7">
<input type="text" name="c" value="<?php echo $data['c']; ?>" class="form-control"required />
</div>
</div>

<div class="form-group ">
<label for="cname" class="control-label col-lg-3">Pilihan D<span class="required">*</span></label>
<div class="col-lg-7">
<input class="form-control" name="d" value="<?php echo $data['d']; ?>" type="text" required />
</div>
</div>

<div class="form-group">
<label class="control-label col-lg-3" for="inputSuccess">Kunci Jawaban</label>
<div class="col-lg-2">
<select name="knc_jawaban" value="<?php echo $data['knc_jawaban']; ?>" class="form-control m-bot15">
<option>A</option>
<option>B</option>
<option>B</option>
<option>C</option>
<option>D</option>
</select>
</div>
</div>


<div class="form-group">
<label class="control-label col-lg-3" for="inputSuccess">Status Aktif</label>
<div class="col-lg-2">
<select name="aktif" value="<?php echo $data['aktif']; ?>" class="form-control m-bot15">
<option>Y</option>
<option>N</option>
</select>
</div>
</div>
<div class="form-group">
<div class="col-lg-offset-3 col-lg-10">
<input type="submit" name="edit" value="Edit Soal" class="btn btn-primary">
<button class="btn btn-danger" type="reset">Batal</button>
</div>
</div>
</form>


<?php
include 'inc/koneksi.php';
if (@$_POST['edit']) {
	@$soal = mysql_real_escape_string($_POST['soal']);
	@$a = mysql_real_escape_string($_POST['a']);
	@$b = mysql_real_escape_string($_POST['b']);
	@$c = mysql_real_escape_string($_POST['c']);
	@$d = mysql_real_escape_string($_POST['d']);
	@$knc_jawaban = mysql_real_escape_string($_POST['knc_jawaban']);
	@$aktif = mysql_real_escape_string($_POST['aktif']);
	mysql_query("update tbl_soal set soal ='$soal',a='$a',b='$b',c='$c',d='$d',knc_jawaban='$knc_jawaban',aktif='$aktif' where id_soal='$kdsoal' ") or die(mysql_error());
        ?>
         <script type="text/javascript">
          alert("Soal berhasil di EDIT !!");  
           window.location.href="?page=guru&action=tampil_pg";
         </script>

         <?php  
}



?>
</fieldset>
