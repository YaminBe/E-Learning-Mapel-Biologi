<!-- Form validations -->              
<div class="row">
<div class="col-lg-12">
<section class="panel">

<div class="panel-body">
<div class="form">
  <img src="icon/2.png">
  <center><img src="icon/11.png"></center>
 



				<?php 
                      $carikode = mysql_query("select max(kode) from tb_forum") or die(mysql_error());
                      $datakode = mysql_fetch_array($carikode);
                      if ($datakode) {
                        $nilaikode = substr($datakode[0], 1);
                        $kode = (int) $nilaikode;
                        $kode = $kode + 1;
                        $hasilkode= "F" .str_pad($kode, 3, "0", STR_PAD_LEFT);

 
                      } else{

                        $hasilkode = "F001";


                      }


                      ?>
                       
<form class="form-validate form-horizontal" id="feedback_form" method="post" action="" enctype="multipart/form-data">
<div class="form-group ">
<label for="cname" class="control-label col-lg-2">Kode Diskusi<span class="required">*</span></label>
<div class="col-lg-7">
<input type="text" name="kode" class="form-control" value="<?php echo "$hasilkode";?>" />
</div>
</div>
<div class="form-group ">
<label for="cname" class="control-label col-lg-2">Nama<span class="required">*</span></label>
<div class="col-lg-7">
<input type="text" name="nama" class="form-control"required />
</div>
</div>
<div class="form-group ">
<label for="cname" class="control-label col-lg-2"> Judul Diskusi<span class="required">*</span></label>
<div class="col-lg-7">
<input type="text" name="judul" class="form-control"required />
</div>
</div>
<div class="form-group ">
<label for="cname" class="control-label col-lg-2"> Pembahasan<span class="required">*</span></label>
<div class="col-lg-5">
	<textarea name="pembahasan" class="form-control"></textarea>
</div>
</div>

<div class="form-group ">
<label for="cname" class="control-label col-lg-2">Keterangan<span class="required">*</span></label>
<div class="col-lg-7">
<input class="form-control" id="cname" name="ket" type="text" required />
</div>
</div>




<div class="form-group">
<div class="col-lg-offset-2 col-lg-10">
<input type="submit" name="kirim" value="Kirim" class="btn btn-primary">
<button class="btn btn-danger" type="reset">Batal</button>
</div>
</div>
</form>
<?php
      $kode = @$_POST['kode'];
      $nama = @$_POST['nama'];     
      $judul = @$_POST['judul'];
      $pembahasan = @$_POST['pembahasan'];
      $ket = @$_POST['ket'];

      $kirim_diskusi = @$_POST['kirim'];

      if ($kirim_diskusi){
      	if ($kode == "" || $nama == "" || $judul == ""|| $pembahasan == "" || $ket == "" ) {
      		?>
      		<script type="text/javascript">
      		alert(" OPPSS !! Inputan Tidak boloh kosong yaa !! ");
      		</script>
      		<?php

      	}else{
      		mysql_query("INSERT INTO tb_forum VALUES ('$kode','$nama','$judul','$pembahasan','$ket')") or die(mysql_error());
            ?>
      		<script type="text/javascript">
      		alert(" Sukses dikirim !! ");      		
      		</script>
      		<?php
      	}



      }
     ?>


</div>
</div>
</section>
</div>
</div>



<!--- tampil dataa user -->


<div class="row">
<div class="col-lg-12">
<section class="panel panel-danger">
<header class="panel-heading">

<center>Daftar Diskusi </center>
</header>


<div class="panel-body">
<div class="table-responsive table-bordered">
<table class="table">
<thead class="panel-body">
<tr>                                                                                
<th>No</th>
<th>Kode Diskusi</th>
<th>Nama</th>
<th>Judul</th>
<th>Pembahasan</th>
<th>Keterangan</th>
<th>Opsi</th>
</tr>                                      
</thead>
<tbody>
	<?php
  $no = 1;

  $batas = 3;
  $hal = @$_GET['hal'];
  if (empty($hal)){
    $posisi = 0;
    $hal =1;

    }else{
      $posisi =($hal - 1) * $batas;
    }

	$sql_user = mysql_query("select * from tb_forum limit $posisi,$batas" ) or die(mysql_error());
  $no =$posisi + 1;
  $cek =mysql_num_rows($sql_user);
  if($cek < 1){
    echo '<tr>  <td> Data Tidak ditemukan !!</td></tr>';

  }else{	

	while ($data = mysql_fetch_array($sql_user)) { ?>
<tr>
  <td><?php echo $no++."." ;?></td>
  <td><?php echo $data['kode'];?></td>
  <td><?php echo $data['nama'];?></td>
  <td><?php echo $data['judul'];?></td>
  <td><?php echo $data['pembahasan'];?></td>
  <td><?php echo $data['ket'];?></td>  
  
  <td>
    <a href="?page=guru&action=edit_forum_g&kdforum=<?php echo $data['kode']; ?>"><button class="btn btn-primary">Edit</button></a>
    <a onclick="return confirm('Apakah kamu yakin ingin Hapus data ini ?')" href="?page=guru&action=hapus_forum_g&kdforum=<?php echo $data['kode']; ?>"><button class="btn btn-danger">Hapus</button></a>
  	
  </td>
</tr>
<?php
 }

} ?>



</tbody>
</table>
 <div class="container">
<hr>
<div class="row">
<div class="col-lg-6">
  
<?php
$jml =mysql_num_rows(mysql_query("SELECT * FROM tb_forum"));
echo "<img src='icon/dt.png'> <button class='btn btn-danger'><h3>".$jml."</button>";

?>
</div>
<div class="col-lg-6">

    <div>
        <ul class="pagination">            
            <?php
            $jml_hal = ceil($jml / $batas);
            for ($i=1; $i<=$jml_hal; $i++){
           
            if($i != $hal){

            }else{

            }
            }
            ?>
</ul>                            


</div>
</div>
<br>
</div>
</div>
<br>
</div>
</section>

</div>
</div>