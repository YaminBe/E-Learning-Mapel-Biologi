


<?php
$kdrpp = @$_GET['kdrpp'];
mysql_query("delete from tb_rpp where id_rpp = '$kdrpp'") or die(mysql_error());
?>
 <script type="text/javascript">
        alert("data berhasil di Hapus!!");  
        window.location.href="?page=guru&action=rpp";
 </script>
