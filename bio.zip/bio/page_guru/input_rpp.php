<div class="row">
<div class="col-lg-11">
<section class="panel panel-primary">
<header class="panel-heading">
<center><h1>Input Data RPP</center>
</header>
<br>

<div class="panel-body">
<div class="form">
<form class="form-validate form-horizontal" id="feedback_form" method="post" action="" enctype="multipart/form-data">

<div class="form-group ">
<label for="cname" class="control-label col-lg-2">Nama RPP<span class="required">*</span></label>
<div class="col-lg-7">
<input type="text" name="nama" class="form-control" placeholder="Masukkan Nama RPP disini ..." required />
</div>
</div>

<div class="form-group">
<label class="col-sm-2 col-sm-2 control-label">Pilih File<span class="required">*</span></label>
<div class="col-sm-8">File yang bisa di Upload maksimal hanya 1 MB.
<input type="file" name="file" class="btn btn-round btn-primary">
</div>
</div>
<div class="form-group ">
<label for="cname" class="control-label col-lg-2"> Keterangan<span class="required">*</span></label>
<div class="col-lg-7">
<textarea name="keterangan" class="form-control"></textarea>
</div>
</div>

<div class="form-group">
<div class="col-lg-offset-2 col-lg-10">
<input type="submit" name="proses" value="Upload" class="btn btn-primary">
<button class="btn btn-danger" type="reset">Cancel</button>
</div>
</div>
</form> 
<?php
include('inc/koneksi.php');
//fungsi untuk mengkonversi size file
function formatBytes($bytes, $precision = 2) { 
$units = array('B', 'KB', 'MB', 'GB', 'TB'); 

$bytes = max($bytes, 0); 
$pow = floor(($bytes ? log($bytes) : 0) / log(1024)); 
$pow = min($pow, count($units) - 1); 

$bytes /= pow(1024, $pow); 

return round($bytes, $precision) . ' ' . $units[$pow]; 
} 

if(@$_POST['proses']){
$allowed_ext	= array('doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'pdf', 'rar', 'zip');

$file_name		= $_FILES['file']['name'];
$file_ext		= strtolower(end(explode('.', $file_name)));
$file_size		= $_FILES['file']['size'];
$file_tmp		= $_FILES['file']['tmp_name'];
$keterangan			= $_POST['keterangan'];
$nama			= $_POST['nama'];
$tgl			= date("Y-m-d");

if(in_array($file_ext, $allowed_ext) === true){
if($file_size < 1044070){
$lokasi = 'file_materi/'.$nama.'.'.$file_ext;
move_uploaded_file($file_tmp, $lokasi);
$in = mysql_query("INSERT INTO tb_rpp VALUES(NULL, '$tgl','$nama', '$file_ext', '$file_size', '$lokasi','$keterangan')");
if($in){

echo '<div class="panel panel-primary">SUCCESS: File berhasil di Upload!</div>';
}else{
echo '<div class="error">ERROR: Gagal upload file!</div>';
}
}else{
echo '<div class="error">ERROR: Besar ukuran file (file size) maksimal 1 Mb!</div>';
}
}else{
echo '<div class="error">ERROR: Ekstensi file tidak di izinkan!</div>';
}
}

?> 



</div>

</div>
</section>
</div>
</div>



<!-- TAMPIL RPP -->


<div class="row">
<div class="col-lg-11">
<section class="panel panel-danger">
<header class="panel-heading">
<center>Data RPP</center>
</header>

<div class="panel-body">
<div class="table-responsive table-bordered">
<table class="table">
<thead class="panel-body">
<tr>                                                                                
<th>No</th>
<th>Tanggal Upload</th>

<th>Nama Silabus</th>
<th>Tipe File</th>
<th>Ukuran File</th>
<th>Keterangan</th>

<th><center>Opsi</center></th>

</tr>
                                      
</thead>

<?php


$sql = mysql_query("SELECT * FROM tb_rpp ORDER BY id_rpp DESC");
if(mysql_num_rows($sql) > 0){
$no = 1;
while($data = mysql_fetch_assoc($sql)){
echo '
<tbody>
<tr>
<td align="center">'.$no.'</td>
<td>'.$data['tanggal_upload'].'</td>
<td>'.$data['nama_file'].'</td>
<td>'.$data['tipe_file'].'</td>
<td>'.formatBytes($data['ukuran_file']).'</td>
<td>'.$data['keterangan'].'</td>
<td><center><a href="?page=guru&action=hapus_rpp&kdrpp='.$data['id_rpp'].'"><button class="btn btn-danger">Hapus</button></td>

</tr>
';
$no++;
}
}else{
echo '
<tr bgcolor="#fff">
<td align="center" colspan="4" align="center">Tidak ada data!</td>
</tr>
';
}
?>



</tbody>
</table>



</div>

</div>
</section>
</div>
</div>