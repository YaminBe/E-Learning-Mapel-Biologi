<?php
$kdsoal = @$_GET['kdsoal'];
mysql_query("delete from tbl_soal where id_soal = '$kdsoal'") or die(mysql_error());
?>
 <script type="text/javascript">
        alert("data berhasil di Hapus!!");  
        window.location.href="?page=guru&action=tampil_pg";
 </script>


