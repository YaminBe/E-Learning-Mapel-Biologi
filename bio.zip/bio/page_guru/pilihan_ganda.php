<section id="container" class="">
    <div class="row">
<div class="col-lg-12">
<section class="panel">
<header class="panel-heading">
  <a href="?page=guru&action=tampil_pg"><button class="btn btn-danger"> Tampilkan Quiz ini</button></a>

<center>FORM INPUTAN QUIZ PILIHAN GANDA</center>
</header>
<div class="panel-body">
<form class="form-validate form-horizontal" id="feedback_form" method="post" action="" enctype="multipart/form-data">
<div class="form-group ">
<label for="cname" class="control-label col-lg-3">Nomor Soal<span class="required">*</span></label>
<div class="col-lg-7">
<input type="text" name="id_soal" class="form-control"/>
</div>
</div>
<div class="form-group ">
<label for="cname" class="control-label col-lg-3">Masukkan Soal<span class="required">*</span></label>
<div class="col-lg-7">
  <textarea name="soal" class="form-control"></textarea>

</div>
</div>


<div class="form-group ">
<label for="cname" class="control-label col-lg-3">Pilihan A<span class="required">*</span></label>
<div class="col-lg-7">
<input type="text" name="a" class="form-control"required />
</div>
</div>
<div class="form-group ">
<label for="cname" class="control-label col-lg-3">Pilihan B<span class="required">*</span></label>
<div class="col-lg-7">
<input type="text" name="b" class="form-control"required />
</div>
</div>
<div class="form-group ">
<label for="cname" class="control-label col-lg-3">Pilihan C<span class="required">*</span></label>
<div class="col-lg-7">
<input type="text" name="c" class="form-control"required />
</div>
</div>

<div class="form-group ">
<label for="cname" class="control-label col-lg-3">Pilihan D<span class="required">*</span></label>
<div class="col-lg-7">
<input class="form-control" name="d" type="text" required />
</div>
</div>

<div class="form-group">
<label class="control-label col-lg-3" for="inputSuccess">Kunci Jawaban</label>
<div class="col-lg-2">
<select name="knc_jawaban" class="form-control m-bot15">
<option>A</option>
<option>B</option>
<option>B</option>
<option>C</option>
<option>D</option>
</select>
</div>
</div>


<div class="form-group">
<label class="control-label col-lg-3" for="inputSuccess">Status Aktif</label>
<div class="col-lg-2">
<select name="aktif" class="form-control m-bot15">
<option>Y</option>
<option>N</option>
</select>
</div>
</div>
<div class="form-group">
<label class="col-sm-3 col-sm-2 control-label">Gambar</label>
<div class="col-sm-8">
<input type="file" name="gambar" class="btn btn-round btn-default">

</div>
</div>



<div class="form-group">
<div class="col-lg-offset-3 col-lg-10">
<input type="submit" name="kirim" value="Upload" class="btn btn-primary">
<button class="btn btn-danger" type="reset">Batal</button>
</div>
</div>
</form>
        <?php
        $id_soal = @$_POST['id_soal'];
        $soal = @$_POST['soal'];        
        $a = @$_POST['a'];
        $b = @$_POST['b'];
        $c = @$_POST['c'];
        $d = @$_POST['d'];
        $knc_jawaban =@$_POST['knc_jawaban'];
        $aktif =@$_POST['aktif'];

        $sumber = @$_FILES['gambar']['tmp_name'];
        $target = 'gambar_soal/';
        $nama_gambar = @$_FILES['gambar']['name'];


        $kirim_soal = @$_POST['kirim']; 

        if ($kirim_soal) {

          if ($soal == "" || $a == "" || $b == "" || $c == "" || $c == ""|| $d =="" || $knc_jawaban =="" || $aktif == ""){

          ?>
           <script type="text/javascript">
           alert("inputan ini ga boleh kosong");</script>
           <?php                    
             
         } else{


          $pindah = move_uploaded_file($sumber, $target.$nama_gambar);

          if ($pindah) {
            mysql_query("insert into tbl_soal values ('$id_soal','$soal','$a','$b','$c','$d','$knc_jawaban','$aktif','$nama_gambar')") or die (mysql_error());
             ?>
           <script type="text/javascript"> alert("data berhasil dikirim ke DATABASE !!"); 
           window.location.href="?page=guru&action=tampil_pg";     
           </script>

           <?php 
         } else{


          ?>
           <script type="text/javascript"> alert("Upload gambar gaal")
           </script>
           <?php
         }

          }

          }


        ?>
</div>

</section>
</section>


