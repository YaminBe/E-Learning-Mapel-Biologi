<!--- tampil dataa user -->
<div class="row">
<div class="col-lg-12">
<section class="panel panel-danger">
<header class="panel-heading">
</header>
<div class="panel-body">
<div class="table-responsive table-bordered">
<table class="table">
<thead class="panel-body">
<tr>                                                                                
<th>No</th>
<th>Kode Soal</th>
<th>Soal</th>
<th>Pilihan A</th>
<th>Pilihan B</th>
<th>Pilihan C</th>
<th>Pilihan D</th>
<th>Kunci Jawaban</th>
<th>Status</th>
<th>Gambar</th>
<th><center>Opsi</center></th>

</tr>                                      
</thead>
<tbody>
	<?php
  $no = 1;

  $batas = 3;
  $hal = @$_GET['hal'];
  if (empty($hal)){
    $posisi = 0;
    $hal =1;

    }else{
      $posisi =($hal - 1) * $batas;
    }

	$sql_user = mysql_query("select * from tbl_soal limit $posisi,$batas" ) or die(mysql_error());
  $no =$posisi + 1;
  $cek =mysql_num_rows($sql_user);
  if($cek < 1){
    echo '<tr>  <td> Data Tidak ditemukan !!</td></tr>';

  }else{


	

	while ($data = mysql_fetch_array($sql_user)) { ?>
<tr>
  <td><?php echo $no++."." ;?></td>
  <td><?php echo $data['id_soal'];?></td>
   <td><?php echo $data['soal'];?></td>
  <td><?php echo $data['a'];?></td>
  <td><?php echo $data['b'];?></td>
  <td><?php echo $data['c'];?></td>
  <td><?php echo $data['d'];?></td>
  <td><?php echo $data['knc_jawaban'];?></td>
  <td><?php echo $data['aktif'];?></td>
  <td><img alt="" class="user-img-div" src="gambar/<?php echo $data['gambar'];?>" width="70px" ></td>
  <td>
  	<a class="btn btn-success" href="?page=guru&action=edit_soal&kdsoal=<?php echo $data['id_soal']; ?>"><i class="icon_check_alt2"></i></a>
    <a onclick="return confirm('Yakin ingin Hapus SOAL yang ini Boss ??')" class="btn btn-danger" href="?page=guru&action=hapus_soal&kdsoal=<?php echo $data['id_soal']; ?>"><i class="icon_close_alt2"></i></a>
    
  </td>
</tr>
<?php
 }

} ?>



</tbody>
</table>
 <div class="container">
<hr>
<div class="row">
<div class="col-lg-6">
  
<?php
$jml =mysql_num_rows(mysql_query("SELECT * FROM tbl_soal"));
echo "<img src='icon/dt.png'> <button class='btn btn-danger'><h2>".$jml."</button>";

?>
</div>
<div class="col-lg-6">

    <div>
        <ul class="pagination">
            <li><a href="#">«</a></li>
            
            <?php
            $jml_hal = ceil($jml / $batas);
            for ($i=1; $i<=$jml_hal; $i++){
            echo "<li><a href='?page=guru&action=tampil_pg&hal= $i'>$i</a></li> ";
            if($i != $hal){

            }else{
            echo "<li></li>";

            }
            }
            ?>
            
<li><a href="#">»</a></li>
</ul> 
</div>
</div>
<br>
</div>
<HR>
	 

<a class="btn btn-primary" data-toggle="modal" href="#myModal"><i class="icon_plus_alt2"></i>
Tambahkan Soal
</a>
<!-- Modal -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
<div class="modal-dialog">
    <div class="modal-content">
        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
            <h4 class="modal-title"> Entry Soal Pilihan Ganda</h4>
        </div>
        <div class="modal-body">

            <form class="form-validate form-horizontal" id="feedback_form" method="post" action="" enctype="multipart/form-data">
<div class="form-group ">
<label for="cname" class="control-label col-lg-3">Nomor Soal<span class="required">*</span></label>
<div class="col-lg-7">
<input type="text" name="id_soal" class="form-control"/>
</div>
</div>
<div class="form-group ">
<label for="cname" class="control-label col-lg-3">Masukkan Soal<span class="required">*</span></label>
<div class="col-lg-7">
  <textarea name="soal" class="form-control"></textarea>

</div>
</div>


<div class="form-group ">
<label for="cname" class="control-label col-lg-3">Pilihan A<span class="required">*</span></label>
<div class="col-lg-7">
<input type="text" name="a" class="form-control"required />
</div>
</div>
<div class="form-group ">
<label for="cname" class="control-label col-lg-3">Pilihan B<span class="required">*</span></label>
<div class="col-lg-7">
<input type="text" name="b" class="form-control"required />
</div>
</div>
<div class="form-group ">
<label for="cname" class="control-label col-lg-3">Pilihan C<span class="required">*</span></label>
<div class="col-lg-7">
<input type="text" name="c" class="form-control"required />
</div>
</div>

<div class="form-group ">
<label for="cname" class="control-label col-lg-3">Pilihan D<span class="required">*</span></label>
<div class="col-lg-7">
<input class="form-control" name="d" type="text" required />
</div>
</div>

<div class="form-group">
<label class="control-label col-lg-3" for="inputSuccess">Kunci Jawaban</label>
<div class="col-lg-2">
<select name="knc_jawaban" class="form-control m-bot15">
<option>A</option>
<option>B</option>
<option>B</option>
<option>C</option>
<option>D</option>
</select>
</div>
</div>


<div class="form-group">
<label class="control-label col-lg-3" for="inputSuccess">Status Aktif</label>
<div class="col-lg-2">
<select name="aktif" class="form-control m-bot15">
<option>Y</option>
<option>N</option>
</select>
</div>
</div>
<div class="form-group">
<label class="col-sm-3 col-sm-2 control-label">Gambar</label>
<div class="col-sm-8">
<input type="file" name="gambar" class="btn btn-round btn-default">

</div>
</div>



<div class="form-group">
<div class="col-lg-offset-3 col-lg-10">
<input type="submit" name="kirim" value="Upload" class="btn btn-primary">
<button class="btn btn-danger" type="reset">Batal</button>
</div>
</div>
</form>
        <?php
        $id_soal = @$_POST['id_soal'];
        $soal = @$_POST['soal'];        
        $a = @$_POST['a'];
        $b = @$_POST['b'];
        $c = @$_POST['c'];
        $d = @$_POST['d'];
        $knc_jawaban =@$_POST['knc_jawaban'];
        $aktif =@$_POST['aktif'];

        $sumber = @$_FILES['gambar']['tmp_name'];
        $target = 'gambar_soal/';
        $nama_gambar = @$_FILES['gambar']['name'];


        $kirim_soal = @$_POST['kirim']; 

        if ($kirim_soal) {

          if ($soal == "" || $a == "" || $b == "" || $c == "" || $c == ""|| $d =="" || $knc_jawaban =="" || $aktif == ""){

          ?>
           <script type="text/javascript">
           alert("inputan ini ga boleh kosong");</script>
           <?php                    
             
         } else{


          $pindah = move_uploaded_file($sumber, $target.$nama_gambar);

          if ($pindah) {
            mysql_query("insert into tbl_soal values ('$id_soal','$soal','$a','$b','$c','$d','$knc_jawaban','$aktif','$nama_gambar')") or die (mysql_error());
             ?>
           <script type="text/javascript"> alert("data berhasil dikirim ke DATABASE !!"); 
           window.location.href="?page=guru&action=tampil_pg";     
           </script>

           <?php 
         } else{


          ?>
           <script type="text/javascript"> alert("Upload gambar gaal")
           </script>
           <?php
         }

          }

          }


        ?>

        </div>
        <div class="modal-footer">
            <button data-dismiss="modal" class="btn btn-default" type="button">Keluar</button>
           
        </div>
    </div>
</div>
</div>
<!-- modal -->


</div>
<br>
</div>
</section>

</div>
</div>