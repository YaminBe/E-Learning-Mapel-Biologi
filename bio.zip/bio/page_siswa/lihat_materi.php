
<!-- TAMPIL MATERI -->


<div class="row">
<div class="col-lg-11">
<section class="panel panel-danger">
<header class="panel-heading">
<center><img src="icon/df_materi.png"></center>
</header>

<div class="panel-body">
<div class="table-responsive table-bordered">
<table class="table">
<thead class="panel-body">
<tr>                                                                                
<th>No</th>
<th>Tanggal Upload</th>
<th>Nama Guru</th>
<th>Pertemuan Ke</th>
<th>Nama Tug</th>
<th>Tipe File</th>
<th>Ukuran File</th>
<th>Keterangan</th>
<th><center>Download</center></th>

</tr>
                                      
</thead>

<?php
//fungsi untuk mengkonversi size file
					function formatBytes($bytes, $precision = 2) { 
					$units = array('B', 'KB', 'MB', 'GB', 'TB'); 
				
					$bytes = max($bytes, 0); 
					$pow = floor(($bytes ? log($bytes) : 0) / log(1024)); 
					$pow = min($pow, count($units) - 1); 
				
					$bytes /= pow(1024, $pow); 
				
					return round($bytes, $precision) . ' ' . $units[$pow]; 
				} 


$sql = mysql_query("SELECT * FROM tb_materi ORDER BY id_materi DESC");
if(mysql_num_rows($sql) > 0){
$no = 1;
while($data = mysql_fetch_assoc($sql)){
echo '
<tbody>
<tr>
<td align="center">'.$no.'</td>
<td>'.$data['tanggal_upload'].'</td>
<td>'.$data['nama_guru'].'</td>
<td>'.$data['pertemuan'].'</td>
<td>'.$data['nama_file'].'</td>
<td>'.$data['tipe_file'].'</td>
<td>'.formatBytes($data['ukuran_file']).'</td>
<td>'.$data['keterangan'].'</td>
<td><a href=" '.$data['file'].'"><img src="icon/download.jpg" width="95" height="38" /></a></td>
</tr>
';
$no++;
}
}else{
echo '
<tr bgcolor="#fff">
<td align="center" colspan="4" align="center">Tidak ada data!</td>
</tr>
';
}
?>



</tbody>
</table>



</div>

</div>
</section>
</div>
</div>