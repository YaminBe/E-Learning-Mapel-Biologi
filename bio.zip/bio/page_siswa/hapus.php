


<?php
$kdtugas = @$_GET['kdtugas'];
mysql_query("delete from tb_tugas_siswa where id_tgs_siswa = '$kdtugas'") or die(mysql_error());
?>
 <script type="text/javascript">
        alert("data berhasil di Hapus!!");  
        window.location.href="?page=tugas&action=upload";
 </script>
