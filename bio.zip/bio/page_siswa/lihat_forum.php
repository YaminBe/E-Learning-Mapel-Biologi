

<!--- tampil dataa forum -->


<div class="row">
<div class="col-lg-12">
<section class="panel panel-danger">
<header class="panel-heading">

<center><h1>Daftar Forum Diskusi </h1></center>
</header>


<div class="panel-body">
<div class="table-responsive table-bordered">
<table class="table">
<thead class="panel-body">
<tr>                                                                                
<th>No</th>
<th>Kode Diskusi</th>
<th>Nama</th>
<th>Judul</th>
<th>Pembahasan</th>
<th>Keterangan</th>
<th>Opsi</th>
</tr>                                      
</thead>
<tbody>
	<?php
  $no = 1;

  $batas = 3;
  $hal = @$_GET['hal'];
  if (empty($hal)){
    $posisi = 0;
    $hal =1;

    }else{
      $posisi =($hal - 1) * $batas;
    }

	$sql_user = mysql_query("select * from tb_forum limit $posisi,$batas" ) or die(mysql_error());
  $no =$posisi + 1;
  $cek =mysql_num_rows($sql_user);
  if($cek < 1){
    echo '<tr>  <td> Data Tidak ditemukan !!</td></tr>';

  }else{	

	while ($data = mysql_fetch_array($sql_user)) { ?>
<tr>
  <td><?php echo $no++."." ;?></td>
  <td><?php echo $data['kode'];?></td>
  <td><?php echo $data['nama'];?></td>
  <td><?php echo $data['judul'];?></td>
  <td><?php echo $data['pembahasan'];?></td>
  <td><?php echo $data['ket'];?></td>  
  
  <td>
    <a onclick="return confirm('Apakah kamu yakin ingin Hapus data ini ?')" href="?page=tugas&action=hapus_forum&kdforum=<?php echo $data['kode']; ?>"><button class="btn btn-danger">Hapus</button></a>
  	
  </td>
</tr>
<?php
 }

} ?>



</tbody>
</table>
 <div class="container">
<hr>
<div class="row">
<div class="col-lg-6">
  
<?php
$jml =mysql_num_rows(mysql_query("SELECT * FROM tb_forum"));
echo "<img src='icon/dt.png'> <button class='btn btn-danger'><h3>".$jml."</button>";

?>
</div>
<div class="col-lg-6">

    <div>
        <ul class="pagination">            
            <?php
            $jml_hal = ceil($jml / $batas);
            for ($i=1; $i<=$jml_hal; $i++){
            echo "<li></a></li> ";
            if($i != $hal){

            }else{
            echo "<li></li>";

            }
            }
            ?>
          </ul> 
</div>
</div>
<br>
</div>
</div>
<br>
</div>
</section>

</div>
</div>